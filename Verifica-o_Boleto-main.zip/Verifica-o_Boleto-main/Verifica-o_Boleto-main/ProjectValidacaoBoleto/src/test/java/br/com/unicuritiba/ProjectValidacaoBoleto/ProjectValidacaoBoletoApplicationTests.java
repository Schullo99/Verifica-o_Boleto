package br.com.unicuritiba.ProjectValidacaoBoleto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectValidacaoBoletoApplicationTests {

	@Test
	void contextLoads() {
	}

}
