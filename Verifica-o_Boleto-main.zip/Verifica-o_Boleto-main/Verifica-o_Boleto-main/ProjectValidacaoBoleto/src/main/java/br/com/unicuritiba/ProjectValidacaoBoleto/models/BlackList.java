package br.com.unicuritiba.ProjectValidacaoBoleto.models;

public class BlackList {

}
