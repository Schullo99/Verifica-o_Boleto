package br.com.unicuritiba.ProjectValidacaoBoleto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectValidacaoBoletoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectValidacaoBoletoApplication.class, args);
	}

}
