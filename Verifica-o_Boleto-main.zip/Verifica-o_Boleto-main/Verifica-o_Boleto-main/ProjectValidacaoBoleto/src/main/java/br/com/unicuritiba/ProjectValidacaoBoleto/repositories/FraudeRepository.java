package br.com.unicuritiba.ProjectValidacaoBoleto.repositories;

public interface FraudeRepository {

}
